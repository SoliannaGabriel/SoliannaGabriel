/**
 * This code adapted from
 * @author Laurie White
 * 
 * -------
 * I read an article from a website called Maruti Techlabs. I would
 * put the link here but I can't due to the diabling of copy and pasting.
 * I didn't use any code from this website, rather, I read it to kind
 * of learn what a ChatBot is supossed to do becasue I was confused in calss.
 * However, for esentially every line of my code, I referenced Nadyah's project.
 * I was really confused and she was nice enough to go over everything with me
 * after school the other day (thank you, Nadyah!).
 * I hope this isn't a problem, Mr. Jones!
 */
 
public class Chatbot
{
	/**
	 * Gets a default greeting.
	 * @return String
	 */
	 
	 String name = "not given";
	 String movie = "not given";
	 String petName = "not given";
	 String petType = "not given";
	 String color = "not given";
	 
	public String greeting() {
		return "Hi! how are you?";
	}
	
	/**
	 * Resturns a response to a user statement
	 * 
	 * @param statement
	 * @return String
	 */
	public String getResponse(String statement) {
		String response = "";
		if (statement.indexOf("animal") >= 0)
		{
		    response = "Do you have any pets?";
		} else if (statement.indexOf("I named my pet") >= 0) {
		    petName = pet(statement);
		    response = "You know, " + petName + " sounds really cool!";
	    } else if (statement.indexOf("My pet is a") >= 0){
		    petType = pet(statement);
		    response = "OMG! I THINK " + petType + " ARE AWESOME!   ";
        } else if (statement.indexOf ("What is my pet's name?") >= 0){
            response = pet(statement);
        
        } else if (
            (statement.indexOf("mother") >= 0 ||
            statement.indexOf("brother") >= 0 ||
            statement.indexOf("sister") >= 0 ||
            statement.indexOf("father") >= 0
            )) {
	    response = "What's your family like?";   
	    } else if (
	  statement.indexOf("weather") >= 0 ||
	    statement.indexOf("sun") >= 0 ||
	    statement.indexOf("rain") >= 0 ) {
	      
	      response = "I love the weather here!";
	  } else if 
	    (
	    statement.indexOf("day") >= 0 ||
	    statement.indexOf("today") >= 0
	    )
	    {
	        response = "What did you do today?";
	        
	    } else if 
	        (statement.indexOf("film") >= 0){
	            response = "What's the best movie you've seen this year?";
	            
	    } else if 
	     (statement.indexOf("show") >= 0 ||
	     statement.indexOf("TV") >= 0 ||
	     statement.indexOf("Disney+") >= 0){
	        response = "What's your favorite show??";
	        
	        //
	    } else if (statement.indexOf("Mr. ") >= 0){
	        response = "Tell me more about him!";
	        
	    } else if (statement.indexOf("Ms. ") >= 0){ 
	        response = "Tell me more about her!";
	        
	    } else if (statement.indexOf("Mx. ") >= 0){
	        response = "What are they like?";
	        
	    } else if (statement.indexOf("My name is ") >= 0){
	        name = keyword(statement);
	        response = "Hi " + name;
	        
	    } else if (statement.indexOf("My favorite color is") >= 0){
	        color = keyword(statement);
	        response = "Woah. I love " + color + " too!";
	        
	    } else if (statement.indexOf("What is my name?") >= 0){
	        response = keyword(statement);
	        
	    } else if (statement.indexOf("What is my favorite color?") >= 0){
	        response = keyword(statement);
	        
	    } else if (statement.indexOf("My favorite movie is") >= 0){
	        movie = move(statement);
	        response = "Your favorite movie is " + movie;
	        
	    } else if (statement.indexOf("What is my favorite movie?") >= 0){
	        response = move(statement);
	        
	    } else if (statement.indexOf("What do you know about me") >= 0){
	        response = "Your name was " + name + ", Your favorite color was " +
	        color + ", Your pet is a " + petType + " named " + petName +
	        ", Your favorite movie was " + movie;
	        
	        
	    } else if (statement.trim().length() <= 1){
	        response = "Please type an actual response";
            
            //
            
        } else {
            response = randomResponse();
        }
        return response;
        
	}

	/**
	 * Pick a default response to use if nothing else fits.
	 * @return String
	 */
	private String randomResponse()
	{
		int NUMBER_OF_RESPONSES = 12;
		double responseIndex = Math.random();
		int whichResponse = (int)(responseIndex * NUMBER_OF_RESPONSES);
		String response = "";
		
		if (whichResponse == 0)
		{
			response = "Wow, that's so cool!";
		}
		else if (whichResponse == 1)
		{
			response = "Tell me more about";
		}
		else if (whichResponse == 2)
		{
			response = "That's really interesting!";
		}
		else if (whichResponse == 3)
		{
			response = "Can we talk about something else?";
		}
		else if (whichResponse == 4)
		{
			response = "Booooring.";
		}
		else if (whichResponse == 5)
		{
			response = "You really like to talk, don't you?";
		}
		return response;
	}
	
	public String keyword(String userInput){
	    if (userInput.indexOf("My favorite color is") >= 0){
	        String coor = userInput.substring(21);
	        return color;
	    } else if (userInput.indexOf("My name is") >= 0){
	        String name = userInput.substring(11);
	        return name;
	        
	   
	    } else if (userInput.indexOf("What is my favorite color") >= 0){
	        return "Your name is " + name;
	        
	    } else if (name == "" || color == ""){
	        return "You haven't given me this info yet";
	    } else {
	        return "error, pease repeat that";
	 }
}
        public String pet(String input) {
         if(input.indexOf("My pet's name is") >= 0){
            String petName = input.substring(17);
            return petName;
        } else if (input.indexOf("My pet is a") >= 0){
            String petType = input.substring(12);
            return petType;
        } else if (input.indexOf("What is my pet's name?") >= 0){
            return "Your " + petType + " is named " + petName;
        } else {
            return "";
        }
    }
	    public String move(String favMovie){
	        if (favMovie.indexOf("My favorite movie is") >= 0){
	            String movie = favMovie.substring(21);
	            return movie;
	        }else if (favMovie.indexOf ("What is my favorite movie?") >= 0){
	            return "Your favorite movie is " + movie;
	        } else {
	            return "";
	        }
	   }
	}